                                                                                    EE4708: FINAL EXAM
                                                                                    
                                                                       SUBMITTED BY: GAUTHAM GOVIND A: EE19B022
                                        --------------------------------------------------------------------------------------------
                                        
The submission folder contains the following files:

Final_Exam_EE19B022.pdf                - The final report containing the analysis of the financial data dataset as well as reworked versions of assignments
Final_EE19B022.ipynb                   - Jupyter Notebook containing all the python code written for the financial data dataset
Assignment1_EE19B022_reworked.ipynb    - Reworked Jupyter Notebook containing all the python code written for the assignment 1
Assignment2_EE19B022_reworked.ipynb    - Reworked Jupyter Notebook containing all the python code written for the assignment 2
Assignment3_EE19B022_reworked.ipynb    - Reworked Jupyter Notebook containing all the python code written for the assignment 3
Assignment4_EE19B022_reworked.ipynb    - Reworked Jupyter Notebook containing all the python code written for the assignment 4
Assignment5_EE19B022_reworked.ipynb    - Reworked Jupyter Notebook containing all the python code written for the assignment 5
Assignment6_EE19B022.ipynb             - Jupyter Notebook containing all the python code written for the assignment 6


