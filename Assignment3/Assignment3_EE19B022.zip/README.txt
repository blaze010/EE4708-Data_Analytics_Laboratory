                                                                                    EE4708:ASSIGNMENT 3
                                                                                    
                                                                       SUBMITTED BY: GAUTHAM GOVIND A: EE19B022
                                        --------------------------------------------------------------------------------------------
                                        
The submission folder contains the following files:

Assignment3_EE19B022.pdf      - The final report containing all of the assignment
Assignment3_EE19B022.ipynb    - Jupyter Notebook containing all the python code written for the assignment
Assignment3_EE19B022.html     - HTML file containing a frozen copy of the jupyter notebook for easy reference
Assignment3_EE19B022.tex      - Tex file used for generating the report
sample.bib                    - Bibliography file used by the tex file
